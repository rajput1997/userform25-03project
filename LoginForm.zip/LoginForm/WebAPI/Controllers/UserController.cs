﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using Utility;
using Microsoft.AspNetCore.Authorization;
using System;
using Test_Model;
using UserForm.Models;
using System.Web.Http.Description;

namespace WebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserController : ControllerBase
    {
        private readonly DAL.UserDbContext _auc;
        //private readonly Resource1 _resource;
        public UserController(DAL.UserDbContext auc) //Resource1 resource
        {
            _auc = auc;
            //_resource = resource;
        }
        [AllowAnonymous]
        //[Route("UserController")]
        [HttpGet("getuser")]
        public IActionResult GetUser()
        {
            try
            {
                var result = _auc.UserRegistration.ToList();
                return Ok(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        // GET api/<UserController>/5
        [HttpGet("GetWithId/{id:int}")]
        public IActionResult GetWithId(int id)
        {
            try
            {
                var result = _auc.UserRegistration.FirstOrDefault(s => s.UserId == id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [HttpGet]
        public IActionResult AddUser()
        {
            return null;
        }
        // POST api/<UserController>
        [Route("AddUser")]
        [HttpPost]

        public IActionResult AddUser(ViewModel model)
        {
            try
            {
                if (model != null)
                {
                    model.Pwd = EncDecPassword.MD5Hash(model.Pwd.ToString());
                    _auc.UserRegistration.Add(model);
                    _auc.SaveChanges();
                    return Ok(model);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }
         // PUT api/<UserController>/5
         [HttpPut("Update")]
         
        public IActionResult Update(ViewModel user)
        {
            try
            {
               // var user = _auc.UserRegistration.FirstOrDefault(s => s.UserId == Id); 
                if (user != null)
                {       
                    _auc.UserRegistration.Update(user);
                    _auc.SaveChanges();
                    return Ok(user);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }

        // DELETE api/<UserController>/5
        [HttpDelete("DeleteById/{id}")]

        public IActionResult DeleteById(int id)
        {
            try
            {
                var stu = _auc.UserRegistration.FirstOrDefault(s => s.UserId == id);
                if (stu != null)
                {
                    _auc.UserRegistration.Remove(stu);
                    _auc.SaveChanges();
                    return Ok(stu);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }
        //Login api/UserController
        [Route("Login")]
        [HttpPost]
        public IActionResult Login(LoginViewModel loginviewModel)
        {
            var userlist = _auc.UserRegistration.ToList();
            loginviewModel.Pwd = EncDecPassword.MD5Hash(loginviewModel.Pwd);
            var value = _auc.UserRegistration.Where(a => a.Pwd == loginviewModel.Pwd && a.Username == loginviewModel.Username).SingleOrDefault();
            if (loginviewModel != null)
            {
                return Ok(loginviewModel); //Resource1.LoginSuccess
            } 
            else
            {
                return BadRequest();
            }
        }

    }
}

