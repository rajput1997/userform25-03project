﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Test_Model
{
     public class ViewModel
    {
        [Key]
        public int UserId { get; set; }

        [Required(ErrorMessage = "Please Enter Username..")]
        [Display(Name = "UserName")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Please Enter firstname..")]
        [Display(Name = "FirstName")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Please Enter middlename..")]
        [Display(Name = "MiddleName")]
        public string MiddleName { get; set; }

        [Required(ErrorMessage = "Please Enter lastname..")]
        [Display(Name = "LastName")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Please Enter address1..")]
        [Display(Name = "Address1")]
        public string Address1 { get; set; }

        [Required(ErrorMessage = "Please Enter Address2 ..")]
        [Display(Name = "Address2 ")]
        public string Address2 { get; set; }

        [Required(ErrorMessage = "Please Enter email ..")]
        [Display(Name = "Email ")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required(ErrorMessage = "Required")]
        [Display(Name = "mobile number ")]
        [StringLength(10)]
        public string Mobile { get; set; }

        [Required(ErrorMessage = "Please Enter city..")]
        [Display(Name = "City")]
        public string City { get; set; }

        [Required(ErrorMessage = "Please Enter state..")]
        [Display(Name = "State")]
        public string State { get; set; }

        [Required(ErrorMessage = "Please Enter country..")]
        [Display(Name = "Country")]
        public string Country { get; set; }

        [Required(ErrorMessage = "Please Enter zipcode..")]
        [Display(Name = "ZipCode")]
        [StringLength(6)]
        public string ZipCode { get; set; }

        [Required(ErrorMessage = "Please Enter Password...")]
        [Display(Name = "Password")]
        public string Pwd { get; set; }

    }
}
    

