﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace Utility
{
        public class EncDecPassword
        {
            static string key { get; set; } = "A!9HHhi%XjjYY4YP2@Nob009X";
            public static string MD5Hash(string text)
            {

                using (var md5 = new MD5CryptoServiceProvider())
                {
                    using (var tdes = new TripleDESCryptoServiceProvider())
                    {
                        tdes.Key = md5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
                        tdes.Mode = CipherMode.ECB;

                        using (var transform = tdes.CreateEncryptor())
                        {
                            byte[] textBytes = UTF8Encoding.UTF8.GetBytes(text);
                            return Convert.ToBase64String(textBytes);
                        }
                    }
                }
            }
            public static string MD5HashDecrpyt(string text)
            {
                using (var md5 = new MD5CryptoServiceProvider())
                {
                    using (var tdes = new TripleDESCryptoServiceProvider())
                    {
                        tdes.Key = md5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
                        tdes.Mode = CipherMode.ECB;

                        using (var transform = tdes.CreateDecryptor())
                        {
                            byte[] cipherBytes = Convert.FromBase64String(text);
                            return UTF8Encoding.UTF8.GetString(cipherBytes);
                        }
                    }
                }
            }
        }
    }

