﻿using Microsoft.EntityFrameworkCore;
using System;
using DAL;
using Test_Model;
using System.Security.Claims;

namespace DAL
{
    public class UserDbContext : DbContext
    {
        public UserDbContext(DbContextOptions<UserDbContext> options) : base(options)
        {
        }
        public DbSet<ViewModel> UserRegistration { get; set; }        
    }
}